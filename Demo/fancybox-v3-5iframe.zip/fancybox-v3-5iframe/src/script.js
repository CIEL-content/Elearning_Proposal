$('.fancybox').fancybox({
  toolbar  : false,
  smallBtn : true,
  iframe : {
    preload : false
  }
})